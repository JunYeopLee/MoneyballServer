package com.server.moneyball.scoreprediction;

public interface SelectMatchListDao {
	public MatchVOList selectMatchList(int userNum, String today);


}
