package com.server.moneyball.user;

public interface UserModifyDao {

	int modyfyUserPw(int userNum, String pw);

}
