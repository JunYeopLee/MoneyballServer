package com.server.moneyball.user;

import java.util.List;

public class UserVOList {
	private List<UserVO> list;

	public UserVOList() {
		super();
	}

	public UserVOList(List<UserVO> list) {
		super();
		this.list = list;
	}

	public List<UserVO> getList() {
		return list;
	}

}
