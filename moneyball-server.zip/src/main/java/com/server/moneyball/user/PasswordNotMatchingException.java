package com.server.moneyball.user;

@SuppressWarnings("serial")
public class PasswordNotMatchingException extends RuntimeException {

}
