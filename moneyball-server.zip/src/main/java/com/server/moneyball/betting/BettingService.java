package com.server.moneyball.betting;

public interface BettingService {

	void saveUserBetting(UserBettingReq userBettingReq);

}
