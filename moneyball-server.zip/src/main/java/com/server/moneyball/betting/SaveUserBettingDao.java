package com.server.moneyball.betting;

public interface SaveUserBettingDao {

	void insertUserBetting(UserBettingReq userBettingReq);

}
