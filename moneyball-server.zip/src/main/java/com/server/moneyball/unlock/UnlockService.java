package com.server.moneyball.unlock;

public interface UnlockService {

	UnlockVO unlock(UnlockReq unlockReq);
	

}
